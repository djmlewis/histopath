/******************************************************************************
 * Copyright (c) 27/9/2020 8:20     djml.uk E&OE.                             *
 ******************************************************************************/
function scrollToAnchor(btn) {
    // .replace("#","") is legacy of href for convenience of switchover
    document.getElementById(btn.getAttribute("data-href").replace("#","")).scrollIntoView({behavior: "auto", block: "start", inline: "nearest"});
    btn.blur();
}