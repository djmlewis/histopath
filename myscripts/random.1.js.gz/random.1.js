/******************************************************************************
 * Copyright (c) 10/12/2020 9:54     djml.uk E&OE.                            *
 ******************************************************************************/

function btnRandomClicked() {
    if(window.randomCardIndices.length===0) setupShuffledCardIndicesArray();
    const indexToShow = window.randomCardIndices.pop();
    selectThisCardIndex(indexToShow);
}

function setupShuffledCardIndicesArray() {
    window.randomCardIndices = arrayOfIndicesForLength(document.getElementById("select-cards").children.length);
    shuffleThisArray(window.randomCardIndices);
}

function selectThisCardIndex(index) {
    btnFlipThisImageOriginal();
    hideLegendIfAppropriate();
    alignSelectsToSelIndex(["select-cards", "select-cards-toolbox", "select-cards-dropdown"], index);
    cardFaceShowing = frontFace;
    loadCardImage();
}